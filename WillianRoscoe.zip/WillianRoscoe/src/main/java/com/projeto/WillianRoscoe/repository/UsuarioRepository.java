package com.projeto.WillianRoscoe.repository;

import org.springframework.data.repository.CrudRepository;

import com.projeto.WillianRoscoe.model.Usuario;
public interface UsuarioRepository extends CrudRepository<Usuario, Long>{
}
